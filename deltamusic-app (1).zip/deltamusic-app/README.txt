DELTAMUSIC (Android)

Gerekenler: Node.js 18+ ve Android Studio

1) Bu klasörde:        npm install
2) Android ekle:       npx cap add android
3) Simgeyi oluştur:    npm run icons
4) Senkronla:          npx cap sync
5) Android Studio:     npx cap open android
   -> telefonu bağla, Run (▶) ile yükle ya da Build > Build APK

SİMGE (uygulama fotoğrafı)
assets/ klasöründe hazır: icon-only.png, icon-foreground.png, icon-background.png
Kendi resmini kullanmak için bu üç dosyanın üstüne 1024x1024 PNG koy, 3. adımı tekrarla.

Elle yapmak istersen (Android Studio): sol ağaçta app > res klasörüne sağ tık >
New > Image Asset > Foreground'a icon-foreground.png seç, Background rengi 0E1222 yap > Next > Finish.

Uygulama ilk açılışta müzik iznini ister, sonra cihazdaki tüm müzikleri listeler.
Tarayıcıda (www/index.html) açarsan sadece test için MP3 seçtirir.

Not: Arka planda çalma bazı telefonlarda ek ayar ister (foreground service /
pil optimizasyonunu kapatma).
